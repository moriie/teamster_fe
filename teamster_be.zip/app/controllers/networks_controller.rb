class NetworksController < ApplicationController
end
